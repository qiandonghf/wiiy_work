package cn.org.osgi.mvc.command;
/**
 * OSGi.org.cn
 *   TPF��Դ��Ŀ
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * @author bluedavy@gmail.com
 */
public interface WebCommand {

	/**
	 * ��Ӧҳ������
	 * 
	 * @param request
	 * @param response
	 * @return String HTMLƬ��
	 * @throws Exception
	 */
	public String execute(HttpServletRequest request,HttpServletResponse response) throws Exception;
	
}
