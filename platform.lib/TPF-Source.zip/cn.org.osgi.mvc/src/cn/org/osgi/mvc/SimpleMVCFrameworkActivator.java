package cn.org.osgi.mvc;
/**
 * OSGi.org.cn
 *   TPF��Դ��Ŀ
 */
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

/**
 * ����������Bundle Activator
 *
 * @author bluedavy@gmail.com
 */
public class SimpleMVCFrameworkActivator implements BundleActivator {

	private static BundleContext bc=null;
	
	/* (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		bc=context;
	}

	/* (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		bc=null;
	}
	
	public static BundleContext getContext(){
		return bc;
	}

}
