package cn.org.osgi.mvc;
/**
 * OSGi.org.cn
 *   TPF��Դ��Ŀ
 */
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import cn.org.osgi.mvc.command.WebCommand;
/**
 * ����������Ĭ�ϵļ򵥵�Controller
 * 
 * @author bluedavy@gmail.com
 */
public abstract class AbstractController extends HttpServlet {

	// --------------------------------------------------------------Instance Variables
	
	private static final long serialVersionUID = 1L;
	
	private static final String COMMAND_PARAM="action";
	
	// --------------------------------------------------------------Abstract Method
	
	/**
	 * ��ȡĬ��ִ�е�Command����
	 */
	public abstract String getDefaultCommand();
	
	/**
     * ��ȡ����Ĵ�������
     * 
     * @return ErrorHandler
     */
    public abstract ErrorHandler getErrorHandler();
	
	// --------------------------------------------------------------Protected Method

	/*
	 * (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		doPost(request, response);
	}
	
	/*
	 * (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		String action=request.getParameter(COMMAND_PARAM);
		if((action==null)||("".equals(action))){
			action=getDefaultCommand();
		}
		String resultHtml=processAction(action, request, response);
		if((resultHtml!=null)&&(!"".equals(resultHtml))){
			response.setContentType("text/html;charset=GBK");
			PrintWriter out = response.getWriter();
			out.write(resultHtml);
			out.flush();
		}
	}
	
	/*
     * execute associate action
     *  
     * @param action
     * @param request
     * @return
     */
    private String processAction(String action,HttpServletRequest request,HttpServletResponse response){
    	WebCommand command=null;
    	try{
    		BundleContext bc=SimpleMVCFrameworkActivator.getContext();
    		if(bc==null)
    			throw new Exception("BundleContext������");
	    	ServiceReference[] serviceRefs=bc.getAllServiceReferences(WebCommand.class.getName(), "(command="+action+")");
	        if(serviceRefs.length==0){
	        	throw new Exception("ϵͳ��û����Ӧ��Command�������񲻿���");
	        }
	        if(serviceRefs.length>1){
	        	throw new Exception("ϵͳ�ж�Ӧ��Command�ķ��񳬹�1��");
	        }
	    	command=(WebCommand) bc.getService(serviceRefs[0]);
    	}
    	catch(Exception e){
    		return getErrorHandler().handle("��ȡCommand����"+action+"����Ӧ�ķ������",e);
    	}
        try {
            String resultHtml=command.execute(request, response);
            if(resultHtml==null)
            	return processAction(getDefaultCommand(), request, response);
            return resultHtml;
        } 
        catch (Exception e) {
            return getErrorHandler().handle("Command����"+action+"������������",e);
        }
    }
	
}
