package cn.org.osgi.axis.service.impl;
/**
 * OSGi.org.cn
 *   ��OSGi����--ģʽ�����ʵ����Դ��
 */
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

import cn.org.osgi.axis.AxisComponent;
import cn.org.osgi.axis.service.RemoteOSGiServiceCaller;

/**
 * ��������������Axisʵ��Զ�̵���OSGi����
 * 
 * @author bluedavy@gmail.com
 */
public class RemoteOSGiServiceCallerComponent implements
		RemoteOSGiServiceCaller {

	/*
	 * (non-Javadoc)
	 * @see cn.org.osgi.module.axis.service.RemoteOSGiServiceCaller#invokeService(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Object[])
	 */
	public Object invokeService(String serviceName, String methodName,String target, String port,
			Object[] args) {
		Service service=new Service();
		try{
			Call call=(Call)service.createCall();
			call.setTargetEndpointAddress("http://"+target+":"+port+"/"+AxisComponent.AXIS_WEB_CONTEXT+"/services/OSGiServiceCaller?wsdl");
			call.setOperationName("invoke");
			return call.invoke(new Object[]{serviceName,methodName,args});
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}

}
