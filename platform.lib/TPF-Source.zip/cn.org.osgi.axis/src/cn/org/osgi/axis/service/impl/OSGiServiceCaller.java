package cn.org.osgi.axis.service.impl;
/**
 * OSGi.org.cn
 *   ��OSGi����--ģʽ�����ʵ����Դ��
 */
import java.lang.reflect.Method;

import org.osgi.framework.BundleContext;

import cn.org.osgi.axis.AxisComponent;

/**
 * ��������������OSGi�����Webservice
 * 
 * @author bluedavy@gmail.com
 */
public class OSGiServiceCaller {

	// ----------------------------------------------Public Method
	
	/**
	 * ���ò�ִ��OSGi����
	 */
	public Object invoke(String serviceName,String methodName,Object[] args){
		BundleContext bc=AxisComponent.getBundleContext();
		Object service=bc.getService(bc.getServiceReference(serviceName));
		Class[] argsClass=new Class[args.length];
		for (int i = 0; i < args.length; i++) {
			argsClass[i]=args[i].getClass();
		}
		try{
			Method method=service.getClass().getMethod(methodName, argsClass);
			return method.invoke(service, args);
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
}
