package cn.org.osgi.axis;
/**
 * OSGi.org.cn
 *   ��OSGi����--ģʽ�����ʵ����Դ��
 */
import javax.servlet.Servlet;

import org.apache.axis.transport.http.AdminServlet;
import org.apache.axis.transport.http.AxisServlet;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.http.HttpService;
import org.osgi.service.log.LogService;

/**
 * ����������ע��Axis��ص�Servlet
 * 
 * @author bluedavy@gmail.com
 */
public class AxisComponent {
	
	// ------------------------------------------------Instance Variables
	
	public static final String AXIS_WEB_CONTEXT="AXIS"; 
	
	private HttpService http;
	
	private LogService log;
	
	private static BundleContext _bc;
	
	// ------------------------------------------------Public Method

	public void activate(ComponentContext context){
		_bc=context.getBundleContext();
	}
	
	public void deactivate(ComponentContext context){
		_bc=null;
	}
	
	public void setHttp(HttpService service){
		http=service;
		registerServlet();
	}
	
	public void unsetHttp(HttpService service){
		if(http!=service)
			return;
		unregisterServlet();
		http=null;
	}
	
	public void setLog(LogService log){
		this.log=log;
	}
	
	public void unsetLog(LogService log){
		if(this.log!=log)
			return;
		this.log=null;
	}
	
	public static BundleContext getBundleContext(){
		return _bc;
	}
	
	// ------------------------------------------------Private Method
	
	private void registerServlet(){
		AxisServlet axisServlet=new AxisServlet();
		AdminServlet adminServlet=new AdminServlet();
		if(http!=null){
			try {
				http.registerServlet("/"+AXIS_WEB_CONTEXT+"/services",(Servlet)axisServlet, null, null);
				http.registerServlet("/"+AXIS_WEB_CONTEXT+"/servlet/AdminServlet",adminServlet, null, null);
				axisServlet.init();
				adminServlet.init();
				info("�ɹ�ע��Axis���Servlet!");
			} 
			catch (Exception e) {
				error("ע��Axis���Servletʱ���ִ���", e);
			}
		}
	}
	
	private void unregisterServlet(){
		http.unregister("/"+AXIS_WEB_CONTEXT+"/services");
		http.unregister("/"+AXIS_WEB_CONTEXT+"/servlet/AdminServlet");
		info("�ɹ�ж��Axis���Servlet��ע��");
	}
	
	private void info(String msg){
		if(log!=null)
			log.log(LogService.LOG_INFO, "��AXIS��װģ�顿��"+msg);
		else
			System.out.println("��AXIS��װģ�顿��"+msg);
	}
	
	private void error(String msg,Throwable t){
		if(log!=null)
			log.log(LogService.LOG_ERROR, "��AXIS��װģ�顿��"+msg+" ������ϸ��Ϣ��"+t);
		else
			System.err.println("��AXIS��װģ�顿��"+msg+" ������ϸ��Ϣ��"+t);
	}
	
}
