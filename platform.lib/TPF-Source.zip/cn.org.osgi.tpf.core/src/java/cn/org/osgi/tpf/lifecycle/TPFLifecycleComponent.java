package cn.org.osgi.tpf.lifecycle;
/*
 * Triones PF V1.5
 *  ����Equinoxʵ�ֵ�Plugin Framework
 */
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.log.LogService;

import cn.org.osgi.tpf.config.TPFPlugin;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
import cn.org.osgi.tpf.lifecycle.api.LifecycleService;

/**
 * desc��TPF���������������DSע�������ķ���
 *  
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision:  $ $Date: 2005/09/14 01:35:44 $
 */
public class TPFLifecycleComponent{

	// ----------------------------------------------Instance Variables
	
	private TPFPluginConfigService configService;
	
	private LifecycleService lifecycleService;
	
	private LogService log;
	
	// ----------------------------------------------Public Method
	
	public void activate(ComponentContext context){
		start(context.getBundleContext());
	}
	
	public void deactivate(ComponentContext context){
		stop(context.getBundleContext());
	}
	
	public void setConfigService(TPFPluginConfigService configService){
		this.configService=configService;
	}
	
	public void unsetConfigService(TPFPluginConfigService configService){
		if(this.configService!=configService)
			return;
		this.configService=null;
	}
	
	public void setLog(LogService log){
		this.log=log;
	}
	
	public void unsetLog(LogService log){
		if(this.log!=log){
			return;
		}
		this.log=null;
	}
	
	public void setLifecycleService(LifecycleService lifecycleService){
		this.lifecycleService=lifecycleService;
	}
	
	public void unsetLifecycleService(LifecycleService lifecycleService){
		if(this.lifecycleService!=lifecycleService)
			return;
		this.lifecycleService=null;
	}

	// ----------------------------------------------Private Method
	
	/*
	 * ����TPF
	 */
	private void start(BundleContext context){
		List pluginList=configService.getPlugins();
		List resultPluginList=new ArrayList();
		Bundle[] bundles=context.getBundles();
		Map existBundles=new HashMap();
		for (int i = 0; i < bundles.length; i++) {
			existBundles.put(bundles[i].getLocation(),String.valueOf(bundles[i].getBundleId()));
		}
		boolean isOccurError=false;
		for (Iterator iter = pluginList.iterator(); iter.hasNext();) {
			TPFPlugin plugin = (TPFPlugin) iter.next();
			Bundle bundle=null;
			try {
				// �жϴ�Bundle�Ƿ��Ѱ�װ�����Ѱ�װ���������°�װBundle
				if(existBundles.containsKey(plugin.getUrl())){
					long bundleId=Long.parseLong((String) existBundles.get(plugin.getUrl()));
					bundle=context.getBundle(bundleId);
					File bundleFile=new File(plugin.getUrl());
					// FIXME: ��ʱ��ô�ж�
					if(bundleFile.lastModified()>bundle.getLastModified()){
						bundle.update();
					}
					plugin.setId(bundleId);
				}
				else{
					bundle=context.installBundle(plugin.getUrl());
					plugin.setId(bundle.getBundleId());
				}
			} 
			catch (BundleException e) {
				if(log!=null)
					log.log(LogService.LOG_ERROR, "Install bundles in tpf error:"+e, e);
				else
					e.printStackTrace();
				pluginList.remove(plugin);
				isOccurError=true;
				continue;
			}
			if(plugin.getStatus()==TPFPlugin.RUNNING){
				if(bundle.getState()!=Bundle.ACTIVE){
					try {
						bundle.start();
					} 
					catch (BundleException e) {
						isOccurError=true;
						if(log!=null)
							log.log(LogService.LOG_ERROR, "Bundle started error:"+e, e);
						else
							e.printStackTrace();
						plugin.setStatus(TPFPlugin.STOPPED);
					}
				}
			}
			else if(plugin.getStatus()==TPFPlugin.STOPPED){
				if(bundle.getState()==Bundle.ACTIVE){
					try {
						bundle.stop();
					} 
					catch (BundleException e) {
						isOccurError=true;
						if(log!=null)
							log.log(LogService.LOG_ERROR, "Bundle stopped error:"+e, e);
						else
							e.printStackTrace();
						plugin.setStatus(TPFPlugin.RUNNING);
					}
				}
			}
			resultPluginList.add(plugin);
		}
		configService.save(resultPluginList);
		lifecycleService.setStatus(true);
		if(isOccurError){
			if(log!=null)
				log.log(LogService.LOG_WARNING,"Error occurs when application start,please see logs for more information");
			System.out.println("����: ϵͳ���������������������г����˴��������ϵͳ��־��ȡ�������Ϣ��");
		}
		else{
			if(log!=null)
				log.log(LogService.LOG_INFO, "Application started successfully");
			System.out.println("��ʾ��ϵͳ�ѳɹ�������");
		}
	}
	
	/*
	 * ֹͣTPF
	 */
	private void stop(BundleContext context){
		List pluginList=configService.getPlugins();
		boolean isOccurError=false;
		for (Iterator iter = pluginList.iterator(); iter.hasNext();) {
			TPFPlugin plugin = (TPFPlugin) iter.next();
			Bundle bundle=(Bundle)context.getBundle(plugin.getId());
			if(bundle!=null)
				try {
					bundle.stop();
					// bundle.uninstall();
				} 
				catch (BundleException e) {
					isOccurError=true;
					if(log!=null)
						log.log(LogService.LOG_ERROR, "Stop bundles in tpf error:"+e, e);
					else
						e.printStackTrace();
				}
		}
		if(isOccurError){
			if(log!=null)
				log.log(LogService.LOG_WARNING,"Error occurs when application stop,please see logs for more information");
			System.out.println("����: ϵͳ��ֹͣ������ֹͣ�����г����˴��������ϵͳ��־��ȡ�������Ϣ��");
		}
		else{
			if(log!=null)
				log.log(LogService.LOG_INFO, "Application stopped successfully");
			System.out.println("��ʾ��ϵͳ�ѳɹ�ֹͣ��");
		}
	}
	
}