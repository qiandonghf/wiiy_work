package cn.org.osgi.tpf.config;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import java.util.jar.Manifest;
/**
 * desc: TPFPlugin��Manifestά������
 * @author <a href="BlueDavy@gmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public interface TPFPluginManifestService {
    
    // ---------------------------------------------Public Method
    
    /** 
     * Get Key's Config Value From Bundle Location
     * 
     * @param key
     * @param location
     * @throws Exception
     */
    public String getValue(String key,String location) throws Exception;
    
    /** 
     * Get Manifest Object From Bundle location
     * 
     * @param location
     * @throws Exception
     */
    public Manifest get(String location) throws Exception;
    
    /** 
     * Save Manifest Object To Bundle location
     * 
     * @param mf
     * @param location
     * @throws Exception
     */
    public void save(Manifest mf,String location) throws Exception;

}
