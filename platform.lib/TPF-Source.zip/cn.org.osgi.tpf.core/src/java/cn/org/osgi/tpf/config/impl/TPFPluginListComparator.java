package cn.org.osgi.tpf.config.impl;
/*
 * Triones PF V1.5
 *  ����Equinoxʵ�ֵ�Plugin Framework
 */
import java.util.Comparator;

import cn.org.osgi.tpf.config.TPFPlugin;
/**
 * desc��TPF��������в���б��Ƚ���
 *  
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision:  $ $Date: 2005/09/14 01:35:44 $
 */
public class TPFPluginListComparator implements Comparator {

	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	public int compare(Object current, Object next) {
		if(!(current instanceof TPFPlugin) || !(next instanceof TPFPlugin))
			return 0;
		TPFPlugin currentObj=(TPFPlugin)current;
		TPFPlugin nextObj=(TPFPlugin)next;
		if(currentObj.getStartLevel()>nextObj.getStartLevel())
			return 1;
		else if(currentObj.getStartLevel()==nextObj.getStartLevel()){
			if(currentObj.getId()>nextObj.getId())
				return 1;
			else
				return -1;
		}
		else{
			return -1;
		}
	}

}
