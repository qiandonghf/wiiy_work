package cn.org.osgi.tpf.config.impl;
/*
 * Triones PF V1.5
 *  ����Equinoxʵ�ֵ�Plugin Framework
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarInputStream;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import cn.org.osgi.tpf.config.TPFPlugin;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
import cn.org.osgi.tpf.config.TPFPluginManifestService;
import cn.org.osgi.tpf.util.PathParseUtil;
import cn.org.osgi.tpf.util.XStreamUtil;

/**
 * desc��TPFPlugin���ù������
 *  
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision:  $ $Date: 2006-8-11 $
 */
public class TPFPluginConfigComponent implements TPFPluginConfigService,
		TPFPluginManifestService {

	// -----------------------------------------Instance Variables
	
	private static final String TPF_CONFIGFILE_KEY="tpf.plugins.configfile";
	
	private static final String PLUGINS_CONFIG_FILE="/tpf.system.plugins";
	
	private String configFile=null;
	
	// -----------------------------------------Public Method
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#getConfigFile()
	 */
    public String getConfigFile(){
    	if(configFile==null){
    		String configFileProp=System.getProperty(TPF_CONFIGFILE_KEY);
    		if((configFileProp!=null)&&(!"".equals(configFileProp))){
    			return configFileProp;
    		}
    		File file=new File(System.getProperty("user.home")+File.separator+".tpf");
    		if(!file.exists())
    			file.mkdirs();
    		return System.getProperty("user.home")+File.separator+".tpf"+PLUGINS_CONFIG_FILE;
    	}
    	return configFile;
    }
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#setFile(java.lang.String)
	 */
	public void setFile(String configFile) {
		this.configFile=configFile;
	}
	
	/* (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#getPlugins()
	 */
	public List getPlugins() {
		File file=new File(getConfigFile());
		if(!file.exists()){
			return new ArrayList();
		}
		List pluginList=(List)XStreamUtil.fromFile(getConfigFile());
		Collections.sort(pluginList, new TPFPluginListComparator());
		return pluginList;
	}
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#getPlugin(java.lang.String)
	 */
	public TPFPlugin getPlugin(String url) {
		Map pluginsMap=getPluginsMap();
		return (TPFPlugin) pluginsMap.get(url);
	}
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#add(net.triones.pf.config.TPFPlugin)
	 */
	public void add(TPFPlugin plugin) {
		List plugins=getPlugins();
		plugins.add(plugin);
		save(plugins);
	}

	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#update(net.triones.pf.config.TPFPlugin)
	 */
	public void update(TPFPlugin plugin) {
		Map pluginsMap=getPluginsMap();
		pluginsMap.put(plugin.getUrl(), plugin);
		List plugins=new ArrayList(pluginsMap.values());
		save(plugins);
	}
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#remove(net.triones.pf.config.TPFPlugin)
	 */
	public void remove(TPFPlugin plugin) {
		Map pluginsMap=getPluginsMap();
		pluginsMap.remove(plugin.getUrl());
		List plugins=new ArrayList(pluginsMap.values());
		save(plugins);
	}
	
	/* (non-Javadoc)
	 * @see net.triones.pf.config.TPFPluginConfigService#save(java.util.List)
	 */
	public void save(List plugins) {
		XStreamUtil.toFile(plugins, getConfigFile());
	}
	
	/* (non-Javadoc)
     * @see net.triones.pf.manage.TPFPluginManifestService#getValue(java.lang.String, java.lang.String)
     */
    public String getValue(String key,String location) throws Exception{
        String uri=PathParseUtil.getURI(location);
        Manifest mf=get(uri);
        return mf.getMainAttributes().getValue(key);
    }
    
    /*
     * (non-Javadoc)
     * @see net.triones.pf.manage.TPFPluginManifestService#get(java.lang.String)
     */
    public Manifest get(String location) throws Exception{
        String uri=PathParseUtil.getURI(location);
        File file=new File(uri);
        if(file.isDirectory())
            return getFromFile(uri+File.separator+"META-INF"+File.separator+"MANIFEST.MF");
        else
            return getFromJar(uri);
    }
    
    /*
     * (non-Javadoc)
     * @see net.triones.pf.manage.TPFPluginManifestService#save(java.util.jar.Manifest, java.lang.String)
     */
    public void save(Manifest mf,String location) throws Exception{
        String uri=PathParseUtil.getURI(location);
        File file=new File(uri);
        if(file.isDirectory())
            saveToFile(mf,uri+File.separator+"META-INF"+File.separator+"MANIFEST.MF");
        else
            saveToJar(mf,uri);
    }
	
	// -----------------------------------------Private Method
	
	/*
	 * ��ȡMap��ʽ��plugins����������޸ĺ�ɾ������
	 */
	private Map getPluginsMap(){
		List plugins=getPlugins();
		Map pluginsMap=new HashMap();
		for (Iterator iter = plugins.iterator(); iter.hasNext();) {
			TPFPlugin plugin = (TPFPlugin) iter.next();
			pluginsMap.put(plugin.getUrl(), plugin);
		}
		return pluginsMap;
	}
	
	/*
     * Get Manifest Object from MANIFEST.MF
     * 
     * @param manifestFileURI
     * @throws Exception
     */
    private Manifest getFromFile(String manifestFileURI) throws Exception{
        FileInputStream fin=new FileInputStream(manifestFileURI);
        Manifest mf=new Manifest(fin);
        fin.close();
        return mf;
    }
    
    /*
     * Save Manifest Object to MANIFEST.MF
     * 
     * @param mf
     * @param manifestFileURI
     * @throws Exception
     */
    private void saveToFile(Manifest mf,String manifestFileURI) throws Exception{
        FileOutputStream fout=new FileOutputStream(new File(manifestFileURI));
        mf.write(fout);
        fout.flush();
        fout.close();
    }
    
    /*
     * Get Manifest Object from jarFile
     * 
     * @param jarFile
     * @throws Exception
     */
    private Manifest getFromJar(String jarFile) throws Exception{
        JarFile file=new JarFile(jarFile);
        Manifest mf=file.getManifest();
        file.close();
        return mf;
    }
    
    /*
     * Save Manifest Object to jarFile
     * 
     * @param mf
     * @param jarFile
     * @throws Exception
     */
    private void saveToJar(Manifest mf,String jarFile) throws Exception{
        long currTime=System.currentTimeMillis();
        String tempOutFileName=jarFile+currTime;
        JarOutputStream jarOut = new JarOutputStream(new FileOutputStream(tempOutFileName),mf);
        JarInputStream jarIn=new JarInputStream(new FileInputStream(jarFile));
        JarEntry entry=null;
        byte[] buf = new byte[4096];
        while((entry=jarIn.getNextJarEntry())!=null){
            if(entry.getName().indexOf("MANIFEST.MF")!=-1)
                continue;
            
            jarOut.putNextEntry(entry);
            int read;
            while ((read = jarIn.read(buf)) != -1) {
                jarOut.write(buf, 0, read);
            }
            jarOut.closeEntry();
        }
        jarOut.flush();
        jarOut.close();
        jarIn.close();
        
        FileOutputStream fout=new FileOutputStream(jarFile);
        FileInputStream fin=new FileInputStream(tempOutFileName);
        int len;
        while ((len = fin.read(buf)) > 0) {
            fout.write(buf, 0, len);
        }
        fin.close();
        fout.close();
        
        File file=new File(tempOutFileName);
        file.delete();
    }

}
