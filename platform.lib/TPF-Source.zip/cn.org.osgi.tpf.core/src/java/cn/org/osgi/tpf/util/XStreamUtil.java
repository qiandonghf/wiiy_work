package cn.org.osgi.tpf.util;
/*
 * Triones PF V1.5
 *  ����Equinoxʵ�ֵ�Plugin Framework
 */
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.Dom4JDriver;
/**
 * desc������XStream��xmlͨ�ò�����
 * 
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision: $ $Date: 2005/09/14 01:35:44 $
 */
public class XStreamUtil {

	public static boolean usingDom = false;

	public static String toXml(Object obj) {
		XStream xstream = null;
		if (usingDom) {
			xstream = new XStream(new Dom4JDriver());
		} 
		else {
			xstream = new XStream();
		}
		return xstream.toXML(obj);
	}

	public static Object fromXml(String xml) {
		// ��ȡ����
		XStream xstream = null;
		if (usingDom) {
			xstream = new XStream(new Dom4JDriver());
		} 
		else {
			xstream = new XStream();
		}
		return xstream.fromXML(xml);
	}

	/**
	 * �������xml��ָ�����ļ�
	 * 
	 * @param obj
	 * @param filename
	 * @return boolean
	 */
	public static boolean toFile(Object obj, String filename) {
		XStream xstream = null;
		if (usingDom) {
			xstream = new XStream(new Dom4JDriver());
		} else {
			xstream = new XStream();
		}
		FileWriter writer = null;
		ObjectOutputStream out = null;
		boolean flag = false;
		try {
			writer = new FileWriter(filename, false);
			out = xstream.createObjectOutputStream(writer);
			out.writeObject(obj);
			flag = true;
		} 
		catch (IOException e) {
			e.printStackTrace();
		} 
		finally {
			if (out != null) {
				try {
					out.close();
					writer.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
		return flag;

	}

	/**
	 * ��ָ����xml�ļ��ж�ȡ����
	 * 
	 * @param filename
	 * @return Object
	 */
	public static Object fromFile(String filename) {
		// ��ȡ����
		XStream xstream = null;
		if (usingDom) {
			xstream = new XStream(new Dom4JDriver());
		} else {
			xstream = new XStream();
		}
		FileReader reader;
		Object obj = null;
		ObjectInputStream in = null;
		try {
			reader = new FileReader(filename);
			in = xstream.createObjectInputStream(reader);
			obj = in.readObject();
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return obj;
	}

}
