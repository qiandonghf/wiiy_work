package cn.org.osgi.tpf.lifecycle.api.impl;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.log.LogService;

import cn.org.osgi.tpf.config.TPFPlugin;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
import cn.org.osgi.tpf.lifecycle.api.LifecycleService;


/**
 * ��������TPF���ϵͳ���������ڵķ����ʵ��
 *  
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision: 1.6 $ $Date: 2005/09/14 01:35:44 $
 */
public class LifecycleServiceImpl implements LifecycleService {

	// -------------------------------------------Instance Variables
	
	private TPFPluginConfigService configService;
	
	private LogService log;
	
	private boolean status=false;
	
	private BundleContext context;
	
	// -------------------------------------------Public Method
	
	/**
	 * ��������
	 */
	public void activate(ComponentContext context){
		this.context=context.getBundleContext();
	}
	
	/**
	 * ע�������
	 */
	public void deactivate(ComponentContext context){
		this.context=null;
	}
	
	public void setConfigService(TPFPluginConfigService configService){
		this.configService=configService;
	}
	
	public void unsetConfigService(TPFPluginConfigService configService){
		if(this.configService!=configService)
			return;
		this.configService=null;
	}
	
	public void setLog(LogService log){
		this.log=log;
	}
	
	public void unsetLog(LogService log){
		if(this.log!=log){
			return;
		}
		this.log=null;
	}
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.lifecycle.api.LifecycleService#getStatus()
	 */
	public Boolean getStatus() {
		return new Boolean(status);
	}
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.lifecycle.api.LifecycleService#setStatus(boolean)
	 */
	public void setStatus(boolean status) {
		this.status=status;
	}

	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.lifecycle.api.LifecycleService#start()
	 */
	public void start() {
		List pluginList=configService.getPlugins();
		boolean isOccurError=false;
		for (Iterator iter = pluginList.iterator(); iter.hasNext();) {
			TPFPlugin plugin = (TPFPlugin) iter.next();
			Bundle bundle=null;
			try {
				bundle=context.getBundle(plugin.getId());
				bundle.start();
			} 
			catch (BundleException e) {
				isOccurError=true;
				if(log!=null)
					log.log(LogService.LOG_ERROR, "Start Bundle Error:"+e, e);
				else
					e.printStackTrace();
			}
			if(bundle.getState()!=Bundle.ACTIVE)
	        	plugin.setStatus(TPFPlugin.STOPPED);
	        else
	        	plugin.setStatus(TPFPlugin.RUNNING);
		}
		configService.save(pluginList);
		setStatus(true);
		if(isOccurError){
			if(log!=null)
				log.log(LogService.LOG_WARNING,"Error occurs when application start,please see logs for more information");
			System.out.println("����: ϵͳ���������������������г����˴��������ϵͳ��־��ȡ�������Ϣ��");
		}
		else{
			if(log!=null)
				log.log(LogService.LOG_INFO, "Application started successfully");
			System.out.println("��ʾ��ϵͳ�ѳɹ�������");
		}
	}

	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.lifecycle.api.LifecycleService#filterStart(java.lang.String)
	 */
	public void filterStart(String plugins) {
		String[] pluginsArray=plugins.split(",");
		Map pluginsMap=new HashMap();
		for (int i = 0; i < pluginsArray.length; i++) {
			String[] pluginsInfoArray=pluginsArray[i].split("@");
			pluginsMap.put(pluginsInfoArray[0], pluginsInfoArray[1]);
		}
		List pluginList=configService.getPlugins();
		boolean isOccurError=false;
		for (Iterator iter = pluginList.iterator(); iter.hasNext();) {
			TPFPlugin plugin = (TPFPlugin) iter.next();
			Bundle bundle=null;
			try {
				bundle=context.getBundle(plugin.getId());
				if(pluginsMap.containsKey(bundle.getSymbolicName())){
					String needVersion=(String) pluginsMap.get(bundle.getSymbolicName());
					String currVersion=bundle.getHeaders().get("Bundle-Version").toString();
					if(needVersion.equals(currVersion))
						bundle.start();
					else
						bundle.stop();
				}
				else
					bundle.stop();
			} 
			catch (BundleException e) {
				isOccurError=true;
				if(log!=null)
					log.log(LogService.LOG_ERROR, "Start or Stop Bundle Error:"+e, e);
				else
					e.printStackTrace();
			}
			if(bundle.getState()!=Bundle.ACTIVE)
	        	plugin.setStatus(TPFPlugin.STOPPED);
	        else
	        	plugin.setStatus(TPFPlugin.RUNNING);
		}
		configService.save(pluginList);
		setStatus(true);
		if(isOccurError){
			if(log!=null)
				log.log(LogService.LOG_WARNING,"Error occurs when node modules start,please see logs for more information");
			System.out.println("����: �ڵ�ģ�����������������������г����˴��������ϵͳ��־��ȡ�������Ϣ��");
		}
		else{
			if(log!=null)
				log.log(LogService.LOG_INFO, "Node modules started successfully");
			System.out.println("��ʾ���ڵ�ģ����������");
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see net.triones.pf.lifecycle.api.LifecycleService#stop()
	 */
	public void stop() {
		List pluginList=configService.getPlugins();
		boolean isOccurError=false;
		for (Iterator iter = pluginList.iterator(); iter.hasNext();) {
			TPFPlugin plugin = (TPFPlugin) iter.next();
			Bundle bundle=null;
			try {
				bundle=context.getBundle(plugin.getId());
				bundle.stop();
			} 
			catch (BundleException e) {
				isOccurError=true;
				if(log!=null)
					log.log(LogService.LOG_ERROR, "Stop Bundle Error:"+e, e);
				else
					e.printStackTrace();
			}
			if(bundle.getState()!=Bundle.ACTIVE)
	        	plugin.setStatus(TPFPlugin.STOPPED);
	        else
	        	plugin.setStatus(TPFPlugin.RUNNING);
		}
		configService.save(pluginList);
		setStatus(false);
		if(isOccurError){
			if(log!=null)
				log.log(LogService.LOG_WARNING,"Error occurs when application stop,please see logs for more information");
			System.out.println("����: ϵͳ��ֹͣ������ֹͣ�����г����˴��������ϵͳ��־��ȡ�������Ϣ��");
		}
		else{
			if(log!=null)
				log.log(LogService.LOG_INFO, "Application stopped successfully");
			System.out.println("��ʾ��ϵͳ�ѳɹ�ֹͣ��");
		}
	}

}
