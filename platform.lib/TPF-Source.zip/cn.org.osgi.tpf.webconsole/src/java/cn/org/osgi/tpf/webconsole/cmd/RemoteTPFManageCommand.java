package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.axis.service.RemoteOSGiServiceCaller;
import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.lifecycle.api.LifecycleService;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;
/**
 * desc: ����TPF���ϵͳ���������ڵĹ���
 * 
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class RemoteTPFManageCommand implements WebCommand {

	// -------------------------------------------------Instance Variables
	
	private static final String PAGE="RemoteTPFManage.vm";
	
	private RemoteOSGiServiceCaller caller;
	
	// -------------------------------------------------Public Method
	
	public void setCaller(RemoteOSGiServiceCaller caller){
		this.caller=caller;
	}
	
	public void unsetCaller(RemoteOSGiServiceCaller caller){
		if(this.caller!=caller)
			return;
		this.caller=null;
	}
	
	/*
	 * (non-Javadoc)
	 * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public String execute(HttpServletRequest request,HttpServletResponse response)
		throws Exception {
		String ip=request.getParameter("txtIP");
		String port=request.getParameter("txtPort");
		String status=request.getParameter("status");
		String methodName="";
		if("stop".equals(status)){
			methodName="stop";
		}
		else if("start".equals(status)){
			methodName="start";
		}
		caller.invokeService(LifecycleService.class.getName(), methodName, ip, port, new Object[]{});
		Boolean returnValue=(Boolean)caller.invokeService(LifecycleService.class.getName(), "getStatus", ip, port, new Object[]{});
		Context context=new VelocityContext();
		context.put("started", String.valueOf(returnValue));
		context.put("ip", ip);
		context.put("port", port);
		return VelocityUtil.getInstance().renderTemplate(PAGE, context);
	}

}
