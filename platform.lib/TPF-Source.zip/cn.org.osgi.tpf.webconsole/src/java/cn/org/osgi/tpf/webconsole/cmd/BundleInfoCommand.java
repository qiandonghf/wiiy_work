package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PPF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.ComponentContext;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
import cn.org.osgi.tpf.config.TPFPluginManifestService;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;
/**
 * desc: Get information of selected bundle
 * @author <a href="BlueDavy@gmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class BundleInfoCommand implements WebCommand {

    // -----------------------------------------Instance Variables
    
    private static final String PAGE="BundleInfoEdit.vm";
    
    private BundleContext context;
    
    private TPFPluginManifestService manifestService;
    
    private TPFPluginConfigService configService;
    
    // -----------------------------------------Public Method
    
    public void activate(ComponentContext cc){
    	context=cc.getBundleContext();
    }
    
    public void setManifestService(TPFPluginManifestService service){
    	manifestService=service;
    }
    
    public void unsetManifestService(TPFPluginManifestService service){
    	if(manifestService!=service)
    		return;
    	manifestService=null;
    }
    
    public void setConfigService(TPFPluginConfigService service){
    	configService=service;
    }
    
    public void unsetConfigService(TPFPluginConfigService service){
    	if(this.configService!=service)
    		return;
    	configService=null;
    }
    
    /* 
     * ���ӿ�����
     */
    public String execute(HttpServletRequest request,HttpServletResponse response)
        throws Exception {
        String id=(String)request.getParameter("bundleId");
        Bundle bundle=context.getBundle(Long.parseLong(id));
        String page=(String)request.getParameter("page");
        if((page==null)||("".equals(page)))
            page=PAGE;
        
        Context vc=new VelocityContext();
        vc.put("bundle", bundle);
        vc.put("tpfplugin", configService.getPlugin(bundle.getLocation()));
        vc.put("manifest", manifestService.get(bundle.getLocation()));
        return VelocityUtil.getInstance().renderTemplate(page, vc);
    }

}
