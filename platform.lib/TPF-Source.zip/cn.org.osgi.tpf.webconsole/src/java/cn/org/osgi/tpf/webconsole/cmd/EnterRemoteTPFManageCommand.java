package cn.org.osgi.tpf.webconsole.cmd;
/**
 * OSGi.org.cn
 *   TPF��Դ��Ŀ
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;

/**
 * ��������������Զ��TPF�����Ľ���
 *
 * @author bluedavy@gmail.com
 */
public class EnterRemoteTPFManageCommand implements WebCommand {

	// ---------------------------------------------------------Instance Variables
	
	private static final String PAGE="RemoteTPFManage.vm";
	
	// ---------------------------------------------------------Public Method
	
	/* (non-Javadoc)
	 * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public String execute(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Context context=new VelocityContext();
		context.put("port", "80");
		return VelocityUtil.getInstance().renderTemplate(PAGE, context);
	}

}
