package cn.org.osgi.tpf.webconsole.util;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import java.io.File;
import java.io.IOException;
import java.util.Dictionary;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;

import cn.org.osgi.tpf.config.TPFPlugin;

/**
 * desc: Bundle Install Util
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision: 1.6 $ $Date: 2005/09/14 01:35:44 $
 */
public class BundleInstallUtil {

	private static final int ACCESSORY_NUM = 1;

	private static final int MAX_K = 1024;

	private static final int MAX_B = 1024;
	
	public static final int IMG_ATTACH=1;
	
	public static final int FILE_ATTACH=2;

	private static final String SERVER_FILEPATH = "Plugin-Save-Dir";
	
	private static final String FILE_SIZE = "Plugin-Maxsize";

	private static final String SIZE_THRESHOLD = "Plugin-Memory-MaxFileSize";

	private static final String TEMP_PATH = "Plugin-TempPath";
	
	private String startLevel=null;

	/**
	 * Upload Plugin File
	 * 
	 * @param req
	 * @return TPFPlugin
	 * @throws Exception
	 */
	public TPFPlugin intercept(HttpServletRequest req,Dictionary props) throws Exception {
		TPFPlugin plugin=new TPFPlugin();
		String pluginUrl=null;
		String pluginName=null;
		String serverPath=null;
		serverPath = props.get(SERVER_FILEPATH)+File.separator;
        File file=new File(serverPath);
		if(!file.exists())
			file.mkdirs();
		String fileSize = (String) props.get(FILE_SIZE);
		String sizeThreshold = (String) props.get(SIZE_THRESHOLD);
		String tempPath = props.get(TEMP_PATH)+File.separator;
		file=new File(tempPath);
		if(!file.exists())
			file.mkdirs();
		DiskFileUpload upload = new DiskFileUpload();
		upload.setSizeMax(Integer.parseInt(fileSize) * MAX_K * MAX_B);
		upload.setSizeThreshold(Integer.parseInt(sizeThreshold));
		upload.setRepositoryPath(tempPath);
		List fileItems = upload.parseRequest(req);
		Iterator iter = fileItems.iterator();
		String regExp = ".+\\\\(.+)$";

		// �������ļ�����
		String[] allowType = { ".jar",".zip" };
		Pattern p = Pattern.compile(regExp);
		String uploadFile = null;
        String uploadFileName=null;
        FileItem uploadItem=null;
		while (iter.hasNext()) {
			FileItem item = (FileItem) iter.next();
			// �������������ļ�������б�����Ϣ
			if (!item.isFormField()) {
				String name = item.getName();
				long size = item.getSize();
				if ((name == null || name.equals("")) && size == 0)
					continue;
				Matcher m = p.matcher(name);
				boolean result = m.find();
				if (result) {
					boolean errorType=true;
                    for (int temp = 0; temp < allowType.length; temp++) {
						if (m.group(ACCESSORY_NUM).endsWith(allowType[temp])) {
							errorType=false;
                            break;
						}
					}
                    if(errorType)
                        throw new IOException(name + ": �ϴ��Ĳ�����Ͳ�������������zip��jar��ʽ");
                    uploadFileName=m.group(ACCESSORY_NUM);
                    uploadItem=item;
				} 
                else {
					throw new IOException("�ϴ�����ʧ��");
				}
			} 
            else {
				String fieldName = item.getFieldName();
				if ("uploadFile".equals(fieldName)) {
                    uploadFile = item.getString();
				}
                else if("pluginurl".equals(fieldName)){
                	pluginUrl="file:/"+item.getString();
                }
                else if("startLevel".equals(fieldName)){
                	startLevel=item.getString();
                }
                else if("name".equals(fieldName)){
                	pluginName=item.getString();
                }
			}
		}
        
        if((uploadItem!=null)&&(!uploadItem.getName().equals(""))){
            if("1".equals(uploadFile)){
                uploadItem.write(new File(serverPath + uploadFileName));
                pluginUrl="file:/"+serverPath + uploadFileName;
                uploadItem=null;
            }
            else{
                pluginUrl="file:/"+ uploadItem.getName();
            }
        }
        
        plugin.setName(pluginName);
        plugin.setStartLevel(Integer.parseInt(startLevel));
        plugin.setUrl(pluginUrl);
		return plugin;
	}
    
}
