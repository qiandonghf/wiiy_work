package cn.org.osgi.tpf.webconsole.controller;
/**
 * OSGi.org.cn
 *   TPF��Դ��Ŀ
 */
import cn.org.osgi.mvc.AbstractController;
import cn.org.osgi.mvc.ErrorHandler;

/**
 * ����������TPF Webconsole��Controller
 *
 * @author bluedavy@gmail.com
 */
public class TPFWebconsoleController extends AbstractController {

	// --------------------------------------------------Instance Variables
	
	private static final String DEFAULT_COMMAND="INDEX";
	
	private static final long serialVersionUID = 1L;
	
	// --------------------------------------------------Public Method

	/* (non-Javadoc)
	 * @see cn.org.osgi.mvc.AbstractController#getDefaultCommand()
	 */
	public String getDefaultCommand() {
		return DEFAULT_COMMAND;
	}

	/* (non-Javadoc)
	 * @see cn.org.osgi.mvc.AbstractController#getErrorHandler()
	 */
	public ErrorHandler getErrorHandler() {
		return new ErrorHandlerImpl();
	}

}
