package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.jar.Manifest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.ComponentContext;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.config.TPFPlugin;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
import cn.org.osgi.tpf.config.TPFPluginManifestService;
import cn.org.osgi.tpf.webconsole.util.EncodeUtil;

/**
 * desc: Update information of selected bundle
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class BundleInfoUpdateCommand implements WebCommand {

    // -----------------------------------------Instance Variables
    
    private static final String ELEMENT_PREFIX="PLUGININFO-";
    
    private BundleContext context;
    
    private TPFPluginManifestService manifestService;
    
    private TPFPluginConfigService configService;
    
    // -----------------------------------------Public Method
    
    public void activate(ComponentContext bc){
    	context=bc.getBundleContext();
    }
    
    public void setManifestService(TPFPluginManifestService service){
    	this.manifestService=service;
    }
    
    public void unsetManifestService(TPFPluginManifestService service){
    	if(this.manifestService!=service)
    		return;
    	this.manifestService=null;
    }
    
    public void setConfigService(TPFPluginConfigService service){
    	configService=service;
    }
    
    public void unsetConfigService(TPFPluginConfigService service){
    	if(configService!=service)
    		return;
    	configService=null;
    }
    
    /*
     * (non-Javadoc)
     * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public String execute(HttpServletRequest request,HttpServletResponse response)
        throws Exception {
        String id=(String)request.getParameter("bundleId");
        Bundle bundle=context.getBundle(Long.parseLong(id));
        
        Manifest mf=new Manifest();
        Map paramMap=request.getParameterMap();
        Set paramKeys=paramMap.keySet();
        for (Iterator iter = paramKeys.iterator(); iter.hasNext();) {
            String element = (String) iter.next();
            if(!element.startsWith(ELEMENT_PREFIX))
                continue;
            
            mf.getMainAttributes().putValue(element.substring(ELEMENT_PREFIX.length()), request.getParameter(element));
        }
        
        String bundleLocation=bundle.getLocation();
        manifestService.save(mf, bundleLocation);
        bundle.stop();
        bundle.start();
        
        TPFPlugin plugin=new TPFPlugin();
        plugin.setId(bundle.getBundleId());
        plugin.setName(EncodeUtil.toGBK((String)request.getParameter("BASEINFO-name")));
        plugin.setStartLevel(Integer.parseInt(request.getParameter("BASEINFO-startLevel")));
        if(bundle.getState()!=Bundle.ACTIVE)
        	plugin.setStatus(TPFPlugin.STOPPED);
        else
        	plugin.setStatus(TPFPlugin.RUNNING);
        plugin.setUrl(bundleLocation);
        configService.update(plugin);
        
        WebCommand command=(WebCommand) context.getService(context.getServiceReferences(WebCommand.class.getName(), "(command=BUNDLELIST)")[0]);
		if(command!=null)
			return command.execute(request,response);
		throw new Exception("δ�ҵ��б�Command����");
    }

}
