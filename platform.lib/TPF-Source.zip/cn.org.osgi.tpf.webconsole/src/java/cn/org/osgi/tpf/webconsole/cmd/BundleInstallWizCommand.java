package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;

/**
 * desc: The wizard for install new plugin
 * @author <a href="BlueDavy@gmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class BundleInstallWizCommand implements WebCommand {

    // -----------------------------------------Instance Variables
    
    private static final String PAGE="BundleInstallWiz.vm";
    
    // -----------------------------------------Public Method
    
    /* 
     * ���ӿ�����
     */
    public String execute(HttpServletRequest request,HttpServletResponse response)
        throws Exception {
        Context vc=new VelocityContext();       
        return VelocityUtil.getInstance().renderTemplate(PAGE, vc);
    }

}
