package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.lifecycle.api.LifecycleService;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;
/**
 * desc: ����TPF���ϵͳ���������ڵĹ���
 * 
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class TPFManageCommand implements WebCommand {

	// -------------------------------------------------Instance Variables
	
	private static final String PAGE="TPFManage.vm";
	
	private LifecycleService lifecycleService;
	
	// -------------------------------------------------Public Method
	
	public void setLifecycleService(LifecycleService service){
		lifecycleService=service;
	}
	
	public void unsetLifecycleService(LifecycleService service){
		if(this.lifecycleService!=service)
			return;
		this.lifecycleService=null;
	}
	
	/*
	 * (non-Javadoc)
	 * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public String execute(HttpServletRequest request,HttpServletResponse response)
		throws Exception {
		String status=request.getParameter("status");
		if("stop".equals(status)){
			lifecycleService.stop();
		}
		else if("start".equals(status)){
			lifecycleService.start();
		}
        Context vc=new VelocityContext();
        vc.put("started", String.valueOf(lifecycleService.getStatus()));
		return VelocityUtil.getInstance().renderTemplate(PAGE, vc);
	}

}
