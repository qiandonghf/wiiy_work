package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PPF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;

/**
 * desc: Get information of selected bundle
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class IndexCommand implements WebCommand {

    // -----------------------------------------Instance Variables
    
    private static final String PAGE="Index.vm";
    
    private BundleContext context;
    
    // -----------------------------------------Public Method
    
    public void activate(ComponentContext cc){
    	context=cc.getBundleContext();
    }
    
    /*
     * (non-Javadoc)
     * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public String execute(HttpServletRequest request,HttpServletResponse response)
        throws Exception {
        VelocityContext vc=new VelocityContext();
        vc.put("vendor", context.getProperty(Constants.FRAMEWORK_VENDOR));
        vc.put("version", context.getProperty(Constants.FRAMEWORK_VERSION));
        return VelocityUtil.getInstance().renderTemplate(PAGE, vc);
    }

}
