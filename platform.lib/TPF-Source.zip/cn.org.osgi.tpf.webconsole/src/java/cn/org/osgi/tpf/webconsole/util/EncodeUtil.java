/*
 * Triones Framework
 * ���ļ�������2006-2-25
 * triones.sf.net
 */
package cn.org.osgi.tpf.webconsole.util;

/**
 * desc:����ͨ����
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class EncodeUtil {
    
    /**
     * ת��ISO8859_1 -> GBK
     * 
     * @param str1
     * @return
     */
    public static String toGBK(String str1) {
        String str2 = null;
        try {
            if (str1 != null) {
                str2 = new String(str1.getBytes("8859_1"), "GBK");
            } else {
                str2 = "";
            }
        } catch (java.io.UnsupportedEncodingException ue) {
        }

        return str2;
    }

    /**
     * ת�� GBK -> ISO8859_1
     * @param str1
     * @return
     */
    public static String toISO(String str1) {
        String str2 = null;
        try {
            if (str1 != null) {
                str2 = new String(str1.getBytes("gbk"), "8859_1");
            } else {
                str2 = "";
            }
        } catch (java.io.UnsupportedEncodingException ue) {
        }

        return str2;
    }

}
