package cn.org.osgi.tpf.webconsole.util;
/*
 * Triones PF V1.5
 *  ����Equinoxʵ�ֵ�Plugin Framework
 */
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import cn.org.osgi.tpf.config.TPFPlugin;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
/**
 * desc��TPFPluginStatus�ı�ͨ�ò�����
 *  
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision:  $ $Date: 2006-8-11 $
 */
public class TPFPluginStatusUtil {

	// -------------------------------------------Public Method
	
	/**
	 * ����TPF��������в����״̬
	 */
	public static final void updatePluginStatus(BundleContext context,Bundle bundle){
		ServiceReference configServiceRef=context.getServiceReference(TPFPluginConfigService.class.getName());
        TPFPluginConfigService configService=(TPFPluginConfigService)context.getService(configServiceRef);
        TPFPlugin plugin=configService.getPlugin(bundle.getLocation());
        if(bundle.getState()!=Bundle.ACTIVE)
        	plugin.setStatus(TPFPlugin.STOPPED);
        else
        	plugin.setStatus(TPFPlugin.RUNNING);
        configService.update(plugin);
	}
	
}
