package cn.org.osgi.tpf.webconsole.util;
/*
 * Triones PPF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.Properties;

import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.context.Context;
/**
 * desc: Velocityģ�����֧����
 * 
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision: 1.1 $ $Date: 2005/10/19 16:48:13 $
 */
public class VelocityUtil {

	// -----------------------------------------------Instance Variables
	
	private static final String DEFAULT_PAGE_DIR="page/";
	
	private static final String DEFAULT_CHAR_SET = "GBK";
	
	private static final String FILE_ENCODING=System.getProperty("file.encoding");
    
    private static final String CONF_FILE="velocity.properties";
	
	private static VelocityUtil util=null;
	
    private VelocityEngine engine=null;
	
	// -----------------------------------------------Public Method
	
	/**
	 * ��ȡ��ǰ�����Ψһʵ��(Singleton)
	 * 
	 * @return VelocityUtil
	 */
	public static synchronized VelocityUtil getInstance(){
		if(util==null){
			util=new VelocityUtil();
		}
		return util;
	}
	
	/**
	 * ������Ӧ��ģ��ΪHtml
	 * 
	 * @param template
	 * @param context
	 * @return String
	 */
	public String renderTemplate(String template,Context context) throws Exception{
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		OutputStreamWriter writer = new OutputStreamWriter(bytes, FILE_ENCODING);
		engine.mergeTemplate(DEFAULT_PAGE_DIR+template, DEFAULT_CHAR_SET, context, writer);
		writer.flush();
		String outputTemplate=new String(bytes.toByteArray());
		writer.close();
		return outputTemplate;
	}
	
	// -----------------------------------------------Private Method

	/*
	 * ��ʼ��Velocity���� 
	 */
	private VelocityUtil(){
		try {
			engine=new VelocityEngine();
			engine.init(loadVelocityProps());
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * ����Velocity�����ļ�
	 *  
	 * @return Properties
	 */
	private Properties loadVelocityProps() throws Exception{
        Properties props=new Properties();
        InputStream is=getClass().getClassLoader().getResourceAsStream(CONF_FILE);
        props.load(is);
        return props;
	}
	
}
