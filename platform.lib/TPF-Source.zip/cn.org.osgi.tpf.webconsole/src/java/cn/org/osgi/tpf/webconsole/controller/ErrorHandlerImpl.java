package cn.org.osgi.tpf.webconsole.controller;
/**
 * OSGi.org.cn
 *   TPF��Դ��Ŀ
 */
import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.mvc.ErrorHandler;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;
/**
 * ����������TPF Webconsole��Ӧ���ִ���ʱ�Ĵ���
 *
 * @author bluedavy@gmail.com
 */
public class ErrorHandlerImpl implements ErrorHandler {

	// ---------------------------------Instance Variables
    
    private static final String PAGE="Error.vm";
    
    // ---------------------------------Public Method
	
	/* (non-Javadoc)
	 * @see net.triones.pf.webmvc.controller.ErrorHandler#handle(java.lang.Throwable)
	 */
	public String handle(Throwable t) {
		return handle(t.getMessage(),t);
	}

	/* (non-Javadoc)
	 * @see net.triones.pf.webmvc.controller.ErrorHandler#handle(java.lang.String)
	 */
	public String handle(String msg) {
		VelocityContext vc=new VelocityContext();
        vc.put("errInfo", msg);
        try {
            return VelocityUtil.getInstance().renderTemplate(PAGE, vc);
        } 
        catch (Exception e1) {
            e1.printStackTrace();
            return "Velocity render error!";
        }
	}

	/* (non-Javadoc)
	 * @see net.triones.pf.webmvc.controller.ErrorHandler#handle(java.lang.String, java.lang.Throwable)
	 */
	public String handle(String msg, Throwable t) {
		Context vc=new VelocityContext();
        vc.put("errInfo", msg);
        StringWriter writer=new StringWriter();
        t.printStackTrace(new PrintWriter(writer));
        writer.flush();
        try {
        	writer.close();
        	vc.put("errDesc", writer.getBuffer().toString());
        	return VelocityUtil.getInstance().renderTemplate(PAGE, vc);
        } 
        catch (Exception e1) {
            e1.printStackTrace();
            return "Velocity render error!";
        }
	}

}
