package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinoxʵ�ֵ�Plugin Framework
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
/**
 * desc������ϵͳ�Ĳ������
 *  
 * @author <a href="mailto:bluedavy@gmail.com">jerry </a>
 * @version CVS $Revision:  $ $Date: 2006-8-11 $
 */
public class TPFExportCommand implements WebCommand {

	// -----------------------------------------------Instance Variables
	
	private TPFPluginConfigService configService;
	
	// -----------------------------------------------Public Method
	
	public void setConfigService(TPFPluginConfigService service){
		configService=service;
	}
	
	public void unsetConfigService(TPFPluginConfigService service){
		if(this.configService!=service)
			return;
		this.configService=null;
	}
	
	/*
	 * (non-Javadoc)
	 * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public String execute(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String tpfConfigFile=configService.getConfigFile();
		File configFile=new File(tpfConfigFile);
		FileInputStream fis=new FileInputStream(configFile);
		response.reset();
        OutputStream outp = response.getOutputStream();
        try {
            response.setContentType("application/octet-stream");
            response.addHeader("Content-Disposition","attachment; filename=\"tpf.system.plugins\"");
            response.addHeader("Content-Length", "" + configFile.length());
            byte[] b = new byte[1024];
            int len;
            while ((len = fis.read(b)) > 0) {
                outp.write(b, 0, len);
            }
        } 
        catch (Exception e) {
            e.printStackTrace();
        	return "";
        } 
        finally {
            fis.close();
        }
		return "";
	}

}
