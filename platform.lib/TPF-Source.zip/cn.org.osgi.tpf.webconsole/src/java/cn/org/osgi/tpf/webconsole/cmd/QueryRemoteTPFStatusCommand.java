package cn.org.osgi.tpf.webconsole.cmd;
/**
 * OSGi.org.cn
 *   TPF��Դ��Ŀ
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.axis.service.RemoteOSGiServiceCaller;
import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.lifecycle.api.LifecycleService;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;

/**
 * ������������ѯԶ��TPFӦ�õ�״̬
 *
 * @author bluedavy@gmail.com
 */
public class QueryRemoteTPFStatusCommand implements WebCommand {

	// -----------------------------------------------------Instance Variables
	
	private static final String PAGE="RemoteTPFManage.vm";
	
	private RemoteOSGiServiceCaller caller;
	
	// -----------------------------------------------------Public Method
	
	public void setCaller(RemoteOSGiServiceCaller caller){
		this.caller=caller;
	}
	
	public void unsetCaller(RemoteOSGiServiceCaller caller){
		if(this.caller!=caller)
			return;
		this.caller=null;
	}
	
	/* (non-Javadoc)
	 * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public String execute(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String ip=request.getParameter("txtIP");
		String port=request.getParameter("txtPort");
		Boolean returnValue=(Boolean)caller.invokeService(LifecycleService.class.getName(), "getStatus", ip, port, new Object[]{});
		Context context=new VelocityContext();
		context.put("started", String.valueOf(returnValue));
		context.put("ip", ip);
		context.put("port", port);
		return VelocityUtil.getInstance().renderTemplate(PAGE, context);
	}

}
