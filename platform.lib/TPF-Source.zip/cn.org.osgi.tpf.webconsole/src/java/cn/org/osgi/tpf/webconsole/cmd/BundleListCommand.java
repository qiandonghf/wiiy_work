package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.config.TPFPluginConfigService;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;
/**
 * desc: All bundles list installed in tpf
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class BundleListCommand implements WebCommand {

    // -------------------------------------------Instance Variables
    
    private static final String PAGE="BundleList.vm";
    
    private TPFPluginConfigService configService;
    
    // -------------------------------------------Public Method
    
    public void setConfigService(TPFPluginConfigService service){
    	configService=service;
    }
    
    public void unsetConfigService(TPFPluginConfigService service){
    	if(configService!=service)
    		return;
    	configService=null;
    }
    
    /*
     * (non-Javadoc)
     * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public String execute(HttpServletRequest request,HttpServletResponse response)
        throws Exception {
        Context vc=new VelocityContext();
        vc.put("tpfplugins", configService.getPlugins());
        return VelocityUtil.getInstance().renderTemplate(PAGE, vc);
    }

}
