package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.service.component.ComponentContext;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.webconsole.util.TPFPluginStatusUtil;

/**
 * desc: Stop selected bundle
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class BundleStopCommand implements WebCommand {

	// --------------------------------------------------Instance Variables
	
	private BundleContext context;
	
	// --------------------------------------------------Public Method
	
	public void activate(ComponentContext cc){
		context=cc.getBundleContext();
	}
	
    /*
     * (non-Javadoc)
     * @see cn.org.osgi.mvc.command.WebCommand#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
	public String execute(HttpServletRequest request,HttpServletResponse response)
        throws Exception {
        String id=request.getParameter("bundleId");
        Bundle bundle=context.getBundle(Long.parseLong(id));
        bundle.stop();
        
        TPFPluginStatusUtil.updatePluginStatus(context, bundle);
        
        WebCommand command=(WebCommand) context.getService(context.getServiceReferences(WebCommand.class.getName(), "(command=BUNDLELIST)")[0]);
		if(command!=null)
			return command.execute(request,response);
		throw new Exception("δ�ҵ��б�Command����");
    }

}
