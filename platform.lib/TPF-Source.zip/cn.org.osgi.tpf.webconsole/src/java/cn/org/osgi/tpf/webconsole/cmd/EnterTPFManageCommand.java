package cn.org.osgi.tpf.webconsole.cmd;
/*
 * Triones PF V1.5
 *  ����Equinox(����OSGI R4���Plugin Architecture)ʵ�ֵ�Plugin Framework
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import cn.org.osgi.mvc.command.WebCommand;
import cn.org.osgi.tpf.lifecycle.api.LifecycleService;
import cn.org.osgi.tpf.webconsole.util.VelocityUtil;

/**
 * desc: ����TPF����ҳ�� 
 * 
 * @author <a href="BlueDavy@hotmail.com">jerry</a>
 * @version CVS $Revision:  $ $Date:  $
 */
public class EnterTPFManageCommand implements WebCommand {

	// ------------------------------------------------------Instance Variables
	
	private static final String PAGE="TPFManage.vm";
	
	private LifecycleService lifecycleService;
	
	// ------------------------------------------------------Public Method
	
	public void setLifecycleService(LifecycleService lifecycleService){
		this.lifecycleService=lifecycleService;
	}
	
	public void unsetLifecycleService(LifecycleService lifecycleService){
		if(this.lifecycleService!=lifecycleService)
			return;
		this.lifecycleService=null;
	}
	
	/* (non-Javadoc)
	 * @see net.triones.ppf.admin.httpshell.cmd.WebCommand#execute(org.osgi.framework.BundleContext, javax.servlet.http.HttpServletRequest)
	 */
	public String execute(HttpServletRequest request,HttpServletResponse response)
		throws Exception {
		Context vc=new VelocityContext();
		vc.put("started", String.valueOf(lifecycleService.getStatus()));
		return VelocityUtil.getInstance().renderTemplate(PAGE, vc);
	}

}
